

</head><?php

if (isset($_SERVER['HTTP_CF_CONNECTING_IP']) && filter_var($_SERVER['HTTP_CF_CONNECTING_IP'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    $userIp = $_SERVER['HTTP_CF_CONNECTING_IP'];
}
elseif (isset($_SERVER['HTTP_X_REAL_IP']) && filter_var($_SERVER['HTTP_X_REAL_IP'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    $userIp = $_SERVER['HTTP_X_REAL_IP'];
}
else {
    $userIp = $_SERVER['REMOTE_ADDR'];
}

$userAgent = !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'API';
$referer = !empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : (!empty($_SERVER['HTTP_HOST']) ? ('http://' . $_SERVER['HTTP_HOST']) : '');

$subId1 = !empty($_POST['sub1']) ? $_POST['sub1'] : '';
$subId2 = !empty($_POST['sub2']) ? $_POST['sub2'] : '';
$subId3 = !empty($_POST['sub3']) ? $_POST['sub3'] : '';
$subId4 = !empty($_POST['sub4']) ? $_POST['sub4'] : '';
$subId5 = !empty($_POST['sub5']) ? $_POST['sub5'] : '';

$fbpx = !empty($_POST['fbpx']) ? $_POST['fbpx'] : '';

$name = !empty($_POST['name']) ? $_POST['name'] : '';
$phone = !empty($_POST['phone']) ? $_POST['phone'] : '';

$infoData = [
    'country'    => nu<span style="display:none;">wwq</span>ll,               // ст<span style="display:none;">zas</span>рана до<span style="display:none;">lel</span>ставки, ес<span style="display:none;">yol</span>ли не бу<span style="display:none;">lil</span>дет пе<span style="display:none;">zwq</span>редана - бу<span style="display:none;">lil</span>дет оп<span style="display:none;">yep</span>ределена по IP адресу
    'f<span style="display:none;">ivo</span>io'        => $n<span style="display:none;">vva</span>ame,              // Имя
    'p<span style="display:none;">zdq</span>hone'      => $p<span style="display:none;">tpa</span>hone,             // Телефон
    'u<span style="display:none;">vsd</span>ser_ip'    => $u<span style="display:none;">eur</span>serIp,            // ip пользователя
    'u<span style="display:none;">wya</span>ser_agent' => $u<span style="display:none;">kst</span>serAgent,         // Us<span style="display:none;">qzk</span>erAgent пользователя
    'o<span style="display:none;">qyv</span>rder_time' => ti<span style="display:none;">tfw</span>me(),             // ti<span style="display:none;">daf</span>mestamp вр<span style="display:none;">xwt</span>емени заказа
];


// id по<span style="display:none;">dyp</span>тока, на<span style="display:none;">lqs</span>пример bakm
$flow = 'CpSa';

// 5 су<span style="display:none;">rrr</span>байди, на<span style="display:none;">lqs</span>пример su<span style="display:none;">lza</span>bid1:subid2:subid3:subid4:subid5 (не обязательно)
$subid = im<span style="display:none;">kil</span>plode(':', [$<span style="display:none;">adt</span>subId1, $s<span style="display:none;">uid</span>ubId2, $s<span style="display:none;">ult</span>ubId3, $s<span style="display:none;">xwa</span>ubId4, $subId5]);

// ключ
$key = 'de782691d8ef9fc2613b09a865428d6dcb2695a1905914';

// до<span style="display:none;">odz</span>мен API
$domain = 'offerrum.com';

$url = "https://api.{$domain}/webmaster/order/?key={$key}&flow={$flow}&subid={$subid}";

if (f<span style="display:none;">wik</span>unction_exists('curl_init') && $ch = cu<span style="display:none;">yvc</span>rl_init()) {
    cu<span style="display:none;">jvs</span>rl_setopt($ch, CU<span style="display:none;">gpp</span>RLOPT_URL, $url);
    cu<span style="display:none;">jvs</span>rl_setopt($ch, CU<span style="display:none;">aha</span>RLOPT_RETURNTRANSFER, true);
    cu<span style="display:none;">jvs</span>rl_setopt($ch, CU<span style="display:none;">swg</span>RLOPT_POST, true);
    cu<span style="display:none;">jvs</span>rl_setopt($ch, CU<span style="display:none;">uwt</span>RLOPT_POSTFIELDS, $infoData);
    cu<span style="display:none;">jvs</span>rl_setopt($ch, CU<span style="display:none;">fei</span>RLOPT_REFERER, $referer);
    cu<span style="display:none;">jvs</span>rl_setopt($ch, CU<span style="display:none;">cyu</span>RLOPT_HEADER, false);
    $r<span style="display:none;">loq</span>esult = curl_exec($ch);
    curl_close($ch);
}
else {
    $r<span style="display:none;">loq</span>esult = file_get_contents(
        $url,
        false,
        stream_context_create(
            [
                'h<span style="display:none;">hxp</span>ttp' => [
                    'm<span style="display:none;">uoo</span>ethod'  => 'POST',
                    'c<span style="display:none;">giq</span>ontent' => http_build_query($infoData),
                    'h<span style="display:none;">iuq</span>eader'  => "C<span style="display:none;">juo</span>ontent-Type: ap<span style="display:none;">lhx</span>plication/x-www-form-urlencoded\r\n" . "R<span style="display:none;">vjw</span>eferer: {$referer}\r\n",
                ],
            ]
        )
    );
}



//var_dump($result);

if ($<span style="display:none;">exc</span>fbpx) {
    he<span style="display:none;">dae</span>ader('Location: su<span style="display:none;">pyq</span>ccess.php?fbpx=' . urlencode($fbpx));
}
else {
    he<span style="display:none;">dae</span>ader('Location: success.php');
}
