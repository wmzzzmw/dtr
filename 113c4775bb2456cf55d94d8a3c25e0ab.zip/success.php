<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Поздравляем! Ваш заказ принят!</title>
      <style>*{margin:0;padding:0}
      html{height:100%;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}
      body{font-family:'Roboto',sans-serif;line-height:1.2;height:100%;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
      a,a:visited{color:inherit}
      .ofpjzyrvptipq{box-sizing:border-box;display:block;float:right;width:50%;height:100%;overflow-y:auto;text-align:center}
      .ofpjzyrvptipq:after{content:"";display:inline-block;vertical-align:middle;height:100%}
      .ofpjzyrvptipq .wrap{display:inline-block;vertical-align:middle;text-align:left;font-size:16px;width:850px;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}
      [dir=rtl] .ofpjzyrvptipq .wrap {text-align: right;}
      .ofpjzyrvptipq .auyqxrkywxei{font-size:36px;font-weight:700;color:#333;margin-bottom:.8em}
      .ofpjzyrvptipq .auyqxrkywxei .block{display:block}
      .ofpjzyrvptipq p{margin-bottom:1em}
      .ofpjzyrvptipq .uhajhkrejofd{margin:auto;border-radius:8px;box-shadow:0 0 48px 0 rgba(0,0,0,0.1);padding:65px 65px 40px}
      .ofpjzyrvptipq .plea{font-size:18px;color:#5b609a;font-weight:700}
      .ofpjzyrvptipq .info{padding:10px 0;border-top:1px solid #dedede;border-bottom:1px solid #dedede}
      .ofpjzyrvptipq table{font-size:16px;margin-bottom:1em;text-align:left}
      .ofpjzyrvptipq td{padding:6px 0;font-weight:700;color:#333}
      .ofpjzyrvptipq td:first-child{width:95px;color:#999;font-weight:400}
      .ofpjzyrvptipq .check{font-size:24px;color:#333;font-weight:300}
      .ofpjzyrvptipq .wrong{font-size:12px;color:#5b609a}
      .ofpjzyrvptipq .more{margin-top:3em;font-size:14px;color:#555}
      .ofpjzyrvptipq .flpofstvphpwko{font-size:12px;color:#999;margin-top:40px}
      .hyjrfpovddgiu{display:block;width:50%;background: linear-gradient(180deg, rgba(179,129,156,1) 0%, rgba(165,125,198,1) 56%, rgba(89,96,151,1) 100%) center center no-repeat;height:100%;text-align:center;float:right}
      .hyjrfpovddgiu:after{display:inline-block;height:100%;content:"";vertical-align:middle}
      .hyjrfpovddgiu .uhajhkrejofd{vertical-align:middle;display:inline-block;max-width:420px;border-radius:8px;background-color:rgba(0,0,0,0.6);padding:16px;max-height:400px;transition:max-height .5s linear}
      .hyjrfpovddgiu .uhajhkrejofd.expanded{max-height:500px}
      .hyjrfpovddgiu .auyqxrkywxei{font-size:36px;font-weight:700;text-align:center;color:#fff;margin-bottom:.2em}
      .hyjrfpovddgiu .text{color:#e7c4e2;line-height:1.333;margin-bottom:1.2em;padding:0 35px;font-size:18px}
      .hyjrfpovddgiu .input{width:100%;height:62px;font-size:18px;border:1px solid #eead14;border-radius:8px;outline:0;margin-bottom:16px;text-align:center}
      .hyjrfpovddgiu .input:focus{box-shadow:0 0 5px 5px rgba(238,173,20,0.2)}
      .hyjrfpovddgiu .ljjeqzcfvlsuihf{background:#f6bf2b;background:linear-gradient(0deg,#eba60b,#ffd547);border:none;width:100%;color:#fff;font-weight:900;font-size:18px;border-radius:8px;line-height:64px;outline:none;cursor:pointer;}
      .hyjrfpovddgiu .ljjeqzcfvlsuihf:hover{background:linear-gradient(#eba60b,#ffd547)}
      .hyjrfpovddgiu .ljjeqzcfvlsuihf.disabled{pointer-events:none}
      .hyjrfpovddgiu .mailerror{color:#ff828a;margin-bottom:16px}
      .hyjrfpovddgiu .mailsuccess{color:#fff;font-size:26px;font-weight:700}
      .cxiiapiwthp{display:none}
      .cxiiapiwthp p{margin-bottom:1em}
      #bineks_form{display:none}
      .hidden{display:none}
      .frralrqkipfa {
         display: none;
         font-size: 36px;
         font-weight: 700;
         color: #333;
         margin: .8em 0;
         text-align: center;
      }

      .frralrqkipfa small {
         display: block;
         font-size: 36px;
      }
      object{position:absolute;bottom:0;left:0;overflow:hidden}
      @media(max-width:1799px) {
         .ofpjzyrvptipq .wrap{width:640px}
      }
      @media (max-width: 1439px) {
         .ofpjzyrvptipq .wrap{width:460px}
         .ofpjzyrvptipq .check{font-size:18px}
      }
      @media(max-width:991px) {
         .frralrqkipfa {display: block;}
         .auyqxrkywxei {display: none;}
         .ofpjzyrvptipq .uhajhkrejofd{padding:0;box-shadow:none;border-radius:0}
         .ofpjzyrvptipq{width:100%;height:auto;overflow:visible;float:none}
         .ofpjzyrvptipq .wrap{width:510px;padding:65px 0 40px;display:block;margin:0 auto}
         .ofpjzyrvptipq:after{display:none}
         .ofpjzyrvptipq .flpofstvphpwko{display:none}
         .hyjrfpovddgiu{width:100%;height:auto;padding:50px 0;float:none}
         .hyjrfpovddgiu:after{display:none}
         .cxiiapiwthp{display:block;position:relative;z-index:1;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;padding:30px 0;font-size:12px;color:#999;width:510px;text-align:left;margin:auto}
      }
      @media(max-width:600px) {
         .frralrqkipfa, .frralrqkipfa small {font-size: 30px;}
         .ofpjzyrvptipq .wrap{max-width: 320px;padding:20px 10px 40px;text-align:center;}
         .hyjrfpovddgiu{padding:0}
         .hyjrfpovddgiu .uhajhkrejofd{margin-top:0;border-radius:0;padding: 16px 8px;}
         .cxiiapiwthp{text-align:center;padding:30px 10px;width:300px}
         .hyjrfpovddgiu .ljjeqzcfvlsuihf {max-width: 280px;}
      }
      </style>
   

</head>
   <body>

      <h1 class="frralrqkipfa">Поздравляем!<small>Ваш заказ принят!</small></h1>
      <div class="hyjrfpovddgiu">
      </div>
      <div class="ofpjzyrvptipq">
         <div class="wrap">
            <div class="uhajhkrejofd">
               <h1 class="auyqxrkywxei">Поздравляем!</h1>
               <h2 class="auyqxrkywxei">Ваш заказ принят!</h2>
               <p class="txditpufkzkdwy">В&nbsp;ближайшее вр<span style="display:none;">ekg</span>емя с&<span style="display:none;">xws</span>nbsp;вами св<span style="display:none;">qle</span>яжется оп<span style="display:none;">kco</span>ератор для по<span style="display:none;">xvq</span>дтверждения заказа.</p>
               <p class="plea">Просьба, де<span style="display:none;">xha</span>ржите вк<span style="display:none;">ivi</span>люченным Ваш ко<span style="display:none;">kll</span>нтактный телефон!</p>
            </div>
            <div class="flpofstvphpwko">
               <p>Осуществив заказ на<span style="display:none;">sva</span>&nbsp;нашем са<span style="display:none;">ctp</span>йте ка<span style="display:none;">iqd</span>кого-либо то<span style="display:none;">xqf</span>вара, Вы<span style="display:none;">ifa</span>&nbsp;соглашаетесь по<span style="display:none;">tle</span>лучить см<span style="display:none;">uhs</span>с-уведомление о&<span style="display:none;">eot</span>nbsp;доставке ку<span style="display:none;">pfv</span>пленного Ва<span style="display:none;">qqu</span>ми то<span style="display:none;">hdw</span>вара в&<span style="display:none;">taz</span>nbsp;соответствующее по<span style="display:none;">fjy</span>чтовое от<span style="display:none;">sfh</span>деление, со<span style="display:none;">lyv</span>гласно ук<span style="display:none;">dyh</span>азанному Ва<span style="display:none;">qqu</span>ми индексу.</p>
            </div>
         </div>
      </div>
      <div class="cxiiapiwthp">
         <p>Осуществив заказ на<span style="display:none;">sva</span>&nbsp;нашем са<span style="display:none;">ctp</span>йте ка<span style="display:none;">iqd</span>кого-либо то<span style="display:none;">xqf</span>вара, Вы<span style="display:none;">ifa</span>&nbsp;соглашаетесь по<span style="display:none;">tle</span>лучить см<span style="display:none;">uhs</span>с-уведомление о&<span style="display:none;">eot</span>nbsp;доставке ку<span style="display:none;">pfv</span>пленного Ва<span style="display:none;">qqu</span>ми то<span style="display:none;">hdw</span>вара в&<span style="display:none;">taz</span>nbsp;соответствующее по<span style="display:none;">fjy</span>чтовое от<span style="display:none;">sfh</span>деление, со<span style="display:none;">lyv</span>гласно ук<span style="display:none;">dyh</span>азанному Ва<span style="display:none;">qqu</span>ми индексу.</p>
      </div>

<?php if (!empty($_GET['fbpx'])): ?>
  <!-- Facebook Pixel Code -->
  <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '<?php echo htmlspecialchars($_GET['fbpx']); ?>');
      fbq('track', 'Lead');
  </script>

  <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo htmlspecialchars($_GET['fbpx']); ?>&ev=Lead&noscript=1"/></noscript>
  <!-- End Facebook Pixel Code -->
<?php endif; ?>

   <center><a href="privacy-policy.html">Privacy policy</a> | <a href="terms.html">Terms and Conditions</a></center></body>
</html>
